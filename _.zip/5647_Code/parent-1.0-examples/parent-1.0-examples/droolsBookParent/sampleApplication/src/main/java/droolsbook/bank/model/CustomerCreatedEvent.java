package droolsbook.bank.model;

public class CustomerCreatedEvent implements Event {

  public CustomerCreatedEvent(Customer customer) {
    // TODO Auto-generated constructor stub
  }
  
}
