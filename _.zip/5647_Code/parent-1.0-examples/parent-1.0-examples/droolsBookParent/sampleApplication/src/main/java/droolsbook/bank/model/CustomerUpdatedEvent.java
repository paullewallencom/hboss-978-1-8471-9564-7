package droolsbook.bank.model;

public class CustomerUpdatedEvent implements Event {

  public CustomerUpdatedEvent(Customer customer) {
    // TODO Auto-generated constructor stub
  }
  
}
