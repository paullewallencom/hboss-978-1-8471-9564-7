package droolsbook.bank.service.impl;

import droolsbook.bank.model.Event;
import droolsbook.bank.service.CEPService;

public class CEPServiceImpl implements CEPService {

  @Override
  public void notify(Event event) {
    // TODO Auto-generated method stub
    
  }
  
}
