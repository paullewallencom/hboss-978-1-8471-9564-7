package droolsbook.bank.model;

public class User {

  public String getUserId() {
    return "123";
  }
  public String getLanguage() {
    return "en-UK";
  }
  private String userId;
  private String language;
  
  
  
}
