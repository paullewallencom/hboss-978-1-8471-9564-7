package droolsbook.sampleApplication.web;

import droolsbook.bank.model.User;

public class WebSessionUtils {

  public User getUser() {
    User user = new User();
    return user;
  }
  
}
