package droolsbook.bank.model;

public interface Event {

}
