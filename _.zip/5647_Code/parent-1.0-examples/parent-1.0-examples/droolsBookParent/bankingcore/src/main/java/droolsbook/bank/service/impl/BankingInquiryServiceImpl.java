package droolsbook.bank.service.impl;

import droolsbook.bank.model.Account;
import droolsbook.bank.model.Customer;
import droolsbook.bank.service.BankingInquiryService;

public class BankingInquiryServiceImpl implements
    BankingInquiryService {

  public Customer findCustomerByExample(
      Customer customerExample) {
    // TODO Auto-generated method stub
    return null;
  }

  public boolean isAccountNumberUnique(Account accout) {
    return false;
  }

}
