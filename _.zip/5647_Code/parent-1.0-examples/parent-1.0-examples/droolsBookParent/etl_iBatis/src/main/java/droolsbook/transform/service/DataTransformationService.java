package droolsbook.transform.service;

public interface DataTransformationService {
  void etl();
}
