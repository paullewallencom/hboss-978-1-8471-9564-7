package droolsbook.etl;

import java.util.List;

import droolsbook.transform.service.LegacyBankService;

public class MockLegacyBankService implements
    LegacyBankService {

  public List findAccountByCustomerId(Long customerId) {
    // TODO Auto-generated method stub
    return null;
  }

  public List findAddressByCustomerId(Long customerId) {
    // TODO Auto-generated method stub
    return null;
  }

  public List findAllCustomers() {
    // TODO Auto-generated method stub
    return null;
  }

}
