package droolsbook.evaluator.test;

import droolsbook.bank.model.Customer;

public class CustomersHolder {

  private Customer customer1;
  private Customer customer2;
  
  public Customer getCustomer1() {
    return customer1;
  }
  public void setCustomer1(Customer customer1) {
    this.customer1 = customer1;
  }
  public Customer getCustomer2() {
    return customer2;
  }
  public void setCustomer2(Customer customer2) {
    this.customer2 = customer2;
  }
  
  
  
}
