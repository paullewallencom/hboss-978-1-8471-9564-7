package droolsbook.droolsflow.model;

public class Rating {

  private Integer rating;

  public Integer getRating() {
    return rating;
  }

  public void setRating(Integer rating) {
    this.rating = rating;
  }
  
}
