package droolsbook.droolsflow.model;

import java.util.List;

import droolsbook.bank.service.Message;

public class DefaultMessage implements Message {

  public List<Object> getContextOrdered() {
    // TODO Auto-generated method stub
    return null;
  }

  public String getMessageKey() {
    // TODO Auto-generated method stub
    return null;
  }

  public Message.Type getType() {
    // TODO Auto-generated method stub
    return null;
  }

}
